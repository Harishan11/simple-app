require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  await User.deleteMany({ email: { $in: ['admin@example.com', 'user@example.com'] } });
  await User.create([
    { name: 'Asha Admin', email: 'admin@example.com', password: 'admin123', role: 'admin' },
    { name: 'Uma User', email: 'user@example.com', password: 'user123', role: 'user' },
  ]);
  console.log('Seeded: admin@example.com / admin123 and user@example.com / user123');
  process.exit(0);
})();
