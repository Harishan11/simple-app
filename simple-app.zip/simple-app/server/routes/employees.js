const router = require('express').Router();
const { query } = require('express-validator');
const Employee = require('../models/Employee');
const { protect, allow } = require('../middleware/auth');
const { validate } = require('../middleware/error');
const { syncEmployees } = require('../services/sync');

const SORTABLE = ['name', 'email', 'department', 'jobTitle', 'age'];
console.log(SORTABLE);
const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
console.log(escapeRegex);

router.use(protect);

router.get('/',
  query('page').optional().isInt({ min: 1 }).withMessage('page must be 1 or more').toInt(),
  query('limit').optional().isInt({ min: 1, max: 50 }).withMessage('limit must be between 1 and 50').toInt(),
  query('sort').optional().isIn(SORTABLE).withMessage('Cannot sort by that field'),
  query('order').optional().isIn(['asc', 'desc']).withMessage('order must be asc or desc'),
  validate,
  async (req, res, next) => {
    try {
      const { search = '', department = '', sort = 'name', order = 'asc' } = req.query;
      const page = req.query.page || 1, limit = req.query.limit || 10;
      const filter = {};
      if (search.trim()) {
        const rx = new RegExp(escapeRegex(search.trim()), 'i');
        filter.$or = [{ name: rx }, { email: rx }, { jobTitle: rx }];
      }
      if (department) filter.department = department;
      const [items, total] = await Promise.all([
        Employee.find(filter).sort({ [sort]: order === 'desc' ? -1 : 1 }).skip((page - 1) * limit).limit(limit).lean(),
        Employee.countDocuments(filter),
      ]);
      res.json({ items, total, page, pages: Math.max(1, Math.ceil(total / limit)) });
    } catch (e) { next(e); }
  });

router.get('/departments', async (req, res, next) => {
  try { res.json((await Employee.distinct('department')).filter(Boolean).sort()); } catch (e) { next(e); }
});

router.post('/sync', allow('admin'), async (req, res, next) => {
  try { res.json({ message: `Synced ${await syncEmployees()} employees` }); } catch (e) { next(e); }
});

module.exports = router;
