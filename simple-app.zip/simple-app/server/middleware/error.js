const { validationResult } = require('express-validator');

exports.validate = (req, res, next) => {
  const errors = validationResult(req);
  if (errors.isEmpty()) return next();
  res.status(422).json({ message: errors.array()[0].msg, errors: errors.array().map((e) => ({ field: e.path, message: e.msg })) });
};
exports.notFound = (req, res) => res.status(404).json({ message: `Route ${req.originalUrl} not found` });
// eslint-disable-next-line no-unused-vars
exports.errorHandler = (err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ message: err.status ? err.message : 'Something went wrong on our side' });
};
