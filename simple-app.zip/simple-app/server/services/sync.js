const Employee = require('../models/Employee');
const SOURCE_URL = 'https://dummyjson.com/users?limit=100';

// Fetch employees from the external API and upsert them into MongoDB.
async function syncEmployees() {
  const res = await fetch(SOURCE_URL);
  if (!res.ok) throw Object.assign(new Error('Employee API unavailable'), { status: 502 });
  const { users } = await res.json();
  const ops = users.map((u) => ({
    updateOne: {
      filter: { externalId: u.id },
      update: { $set: {
        externalId: u.id, name: `${u.firstName} ${u.lastName}`, email: u.email, phone: u.phone,
        age: u.age, department: u.company?.department, jobTitle: u.company?.title, city: u.address?.city,
      } },
      upsert: true,
    },
  }));
  await Employee.bulkWrite(ops);
  return users.length;
}
module.exports = { syncEmployees };
