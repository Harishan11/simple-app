require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const { notFound, errorHandler } = require('./middleware/error');
const { syncEmployees } = require('./services/sync');
const Employee = require('./models/Employee');

const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN }));
app.use(express.json());

app.use('/api/auth', require('./routes/auth'));
app.use('/api/employees', require('./routes/employees'));
app.use(notFound);
app.use(errorHandler);

(async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('MongoDB connected');
    if ((await Employee.countDocuments()) === 0) {
      console.log(`Employees synced: ${await syncEmployees()}`);
    }
    app.listen(process.env.PORT || 5000, () => console.log('API running'));
  } catch (err) {
    console.error('Startup failed:', err.message);
    process.exit(1);
  }
})();
