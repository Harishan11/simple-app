const { Schema, model } = require('mongoose');

const employeeSchema = new Schema({
  externalId: { type: Number, required: true, unique: true },
  name: { type: String, required: true, index: true },
  email: { type: String, required: true },
  phone: String,
  age: Number,
  department: { type: String, index: true },
  jobTitle: String,
  city: String,
}, { timestamps: true });

module.exports = model('Employee', employeeSchema);
