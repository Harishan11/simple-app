import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth, homeFor } from '../AuthContext.jsx';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [busy, setBusy] = useState(false);

  const validate = () => {
    const e = {};
    if (!/^\S+@\S+\.\S+$/.test(form.email)) e.email = 'Enter a valid email address';
    if (form.password.length < 6) e.password = 'Password must be at least 6 characters';
    return e;
  };

  const submit = async (ev) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e); setServerError('');
    if (Object.keys(e).length) return;
    setBusy(true);
    try {
      const user = await login(form.email, form.password);
      navigate(homeFor(user.role), { replace: true });
    } catch (err) { setServerError(err.message); }
    finally { setBusy(false); }
  };

  const field = (name, label, type) => (
    <label className="field">{label}
      <input type={type} value={form[name]} aria-invalid={!!errors[name]}
        onChange={(e) => setForm({ ...form, [name]: e.target.value })} />
      {errors[name] && <small className="error">{errors[name]}</small>}
    </label>
  );

  return (
    <div className="login-wrap">
      <form className="login-card" onSubmit={submit} noValidate>
        <h1>Sign in</h1>
        <p className="muted">Use your work email to open the employee directory.</p>
        {serverError && <div className="alert" role="alert">{serverError}</div>}
        {field('email', 'Email', 'email')}
        {field('password', 'Password', 'password')}
        <button className="btn" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
        <p className="muted hint">Demo: admin@example.com / admin123, user@example.com / user123</p>
      </form>
    </div>
  );
}
