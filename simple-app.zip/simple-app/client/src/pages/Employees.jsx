import { useCallback, useEffect, useState } from 'react';
import { api } from '../api.js';

const COLUMNS = [
  ['name', 'Name'], ['email', 'Email'], ['department', 'Department'], ['jobTitle', 'Job title'], ['age', 'Age'],
];

export default function Employees({ canSync = false }) {
  const [data, setData] = useState({ items: [], total: 0, pages: 1 });
  const [departments, setDepartments] = useState([]);
  const [q, setQ] = useState({ page: 1, search: '', department: '', sort: 'name', order: 'asc' });
  const [searchInput, setSearchInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  // Debounce search so we don't hit the API on every keystroke.
  useEffect(() => {
    const t = setTimeout(() => setQ((p) => ({ ...p, search: searchInput, page: 1 })), 350);
    return () => clearTimeout(t);
  }, [searchInput]);

  const load = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const params = new URLSearchParams({ ...q, limit: 10 });
      setData(await api(`/employees?${params}`));
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  }, [q]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { api('/employees/departments').then(setDepartments).catch(() => {}); }, []);

  const sortBy = (field) => setQ((p) => ({
    ...p, sort: field, page: 1, order: p.sort === field && p.order === 'asc' ? 'desc' : 'asc',
  }));

  const sync = async () => {
    setNotice(''); setError('');
    try { setNotice((await api('/employees/sync', { method: 'POST' })).message); await load(); }
    catch (e) { setError(e.message); }
  };

  return (
    <>
      <header className="page-head">
        <div>
          <h1>Employees</h1>
          <p className="muted">{data.total} {data.total === 1 ? 'person' : 'people'} found</p>
        </div>
        {canSync && <button className="btn" onClick={sync}>Refresh from source API</button>}
      </header>

      <div className="toolbar">
        <input type="search" placeholder="Search by name, email or job title" aria-label="Search employees"
          value={searchInput} onChange={(e) => setSearchInput(e.target.value)} />
        <select aria-label="Filter by department" value={q.department}
          onChange={(e) => setQ({ ...q, department: e.target.value, page: 1 })}>
          <option value="">All departments</option>
          {departments.map((d) => <option key={d}>{d}</option>)}
        </select>
      </div>

      {notice && <div className="alert ok">{notice}</div>}
      {error && <div className="alert" role="alert">{error} <button className="link" onClick={load}>Try again</button></div>}

      <div className="table-wrap">
        <table>
          <thead><tr>
            {COLUMNS.map(([key, label]) => (
              <th key={key} aria-sort={q.sort === key ? (q.order === 'asc' ? 'ascending' : 'descending') : 'none'}>
                <button className="th-btn" onClick={() => sortBy(key)}>
                  {label}{q.sort === key ? (q.order === 'asc' ? ' ▲' : ' ▼') : ''}
                </button>
              </th>
            ))}
          </tr></thead>
          <tbody>
            {loading && <tr><td colSpan={5} className="center">Loading employees…</td></tr>}
            {!loading && !data.items.length && !error && (
              <tr><td colSpan={5} className="center">No employees match. Try a different search or department.</td></tr>
            )}
            {!loading && data.items.map((e) => (
              <tr key={e._id}>
                <td>{e.name}</td><td>{e.email}</td><td>{e.department}</td><td>{e.jobTitle}</td><td>{e.age}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <footer className="pager">
        <button className="btn ghost" disabled={q.page <= 1} onClick={() => setQ({ ...q, page: q.page - 1 })}>Previous</button>
        <span>Page {data.page || q.page} of {data.pages}</span>
        <button className="btn ghost" disabled={q.page >= data.pages} onClick={() => setQ({ ...q, page: q.page + 1 })}>Next</button>
      </footer>
    </>
  );
}
