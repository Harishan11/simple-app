import { NavLink } from 'react-router-dom';
import { useAuth, homeFor } from '../AuthContext.jsx';

export default function Layout({ children }) {
  const { user, logout } = useAuth();
  return (
    <div className="shell">
      <aside className="sidebar">
        <h2 className="brand">Simple App</h2>
        <nav aria-label="Main">
          <NavLink to={homeFor(user.role)}>Employees</NavLink>
        </nav>
        <div className="me">
          <strong>{user.name}</strong>
          <span>{user.role === 'admin' ? 'Administrator' : 'Team member'}</span>
          <button className="btn ghost" onClick={logout}>Sign out</button>
        </div>
      </aside>
      <main className="content">{children}</main>
    </div>
  );
}
